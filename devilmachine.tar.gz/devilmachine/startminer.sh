./hellminer -c stratum+ssl://eu.luckpool.net:3956 -u RMRHW3sJg4rdccSDwVxUXiqYSbBCCT9TSV.ihkepobenedah -p x --c>
